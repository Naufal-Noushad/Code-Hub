from django import forms

from notes.models import Task

from django.contrib.auth.models import User

class TaskForm(forms.ModelForm):

    class Meta:

        model=Task

        # fields="__all__"

        exclude=("created_date","status","updated_date","user")

        widgets={

            "title":forms.TextInput(attrs={"class":"form-control mb-3"}),

            "description":forms.Textarea(attrs={"class":"form-control mb-3"}),

            "due_date":forms.DateInput(attrs={"class":"form-control mb-3","type":"date"}),

            "category":forms.Select(attrs={"class":"form-control form-select mb-3"}),

            "user":forms.TextInput(attrs={"class":"form-control mb-3"})
        }

class RegistrationForm(forms.ModelForm):

    class Meta:

        model=User

        fields=["username","email","password","first_name","last_name"]

        widgets={

            "username":forms.TextInput(attrs={"class":"form-control mb-3"}),
            "password":forms.PasswordInput(attrs={"class":"form-control mb-3"}),
            "email":forms.EmailInput(attrs={"class":"form-control mb-3"}),
            "first_name":forms.TextInput(attrs={"class":"form-control mb-3"}),
            "last_name":forms.TextInput(attrs={"class":"form-control mb-3"})
        }

class SigninForm(forms.Form):

    username=forms.CharField(widget=forms.TextInput(attrs={"class":"form-control mb-3"}))
    password=forms.CharField(widget=forms.PasswordInput(attrs={"class":"form-control mb-3"}))
